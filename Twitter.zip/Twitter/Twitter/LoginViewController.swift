//
//  LoginViewController.swift
//  Twitter
//
//  Created by Griffin Davidson on 3/5/22.
//  Copyright © 2022 Dan. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    private let resourceURL = "https://api.twitter.com/oauth/request_token"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        
        if UserDefaults.standard.bool(forKey: "isLoggedIn")
        {
            self.performSegue(withIdentifier: "loginToTwitter", sender: self)
        }
    }
    
    @IBAction func loginButton(_ sender: Any)
    {
        TwitterAPICaller.client?.login(url: resourceURL,
            success:
            {
                self.performSegue(withIdentifier: "loginToTwitter", sender: self)
            print("Sucess")
            UserDefaults.standard.set(true, forKey: "isLoggedIn")
            },
            failure: { (Error) in
                print("[Internal Error] Failed to login - LoginViewController.swift Line 31")
            })
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
